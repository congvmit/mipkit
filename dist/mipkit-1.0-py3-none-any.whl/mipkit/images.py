import matplotlib.pyplot as plt

__version__ = '1.0.0'